Navíc oproti základnímu zadání dělám:
- základní kontrola syntaxe prvního vstupu první úlohy
- cost-complexity post-pruning (v odevzdané verzi je vypnut, ale lze jej nastavit pomocí parametru alpha v main.hs)
